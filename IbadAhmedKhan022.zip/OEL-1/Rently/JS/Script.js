










function validateForm (){
    clearErrors();
    var returnVal = true;  
    var regEx = /^[A-Za-z]+$/;
    var name = document.forms['theForm']["fname"].value;
    if (name.length < 5)
    { setError("name", "Length too short*");
        returnVal = false;
    }
   
    var regularExpression  = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+*!=]).*$/;
    var pass = document.forms['theForm']["fpass"].value;
    if (pass.length < 5)
    { setError("pass", "Password too short*");
        returnVal = false;
    }
    else if(!regularExpression.test(pass))
     {
        setError("pass", "Password must contain 1 capital letter and 1 special character*")
        returnVal = false;
    }

   
    
    return returnVal;
}



function clearErrors(){
 errors = document.getElementsByClassName('formError');

 for(let item of errors)
 {
    item.innerHTML = "";

 }

}

function setError(id, error){

    element = document.getElementById(id);
    element.getElementsByClassName('formError')[0].innerHTML = error;


}

function prodcutsPage(){
windows.open("Products.html");


}
$(document).ready(function(){
$('#menuIcon').click(function(){
    $('.sidebar').toggleClass("opensidebar")
});






});
